import Cabecalho from '../components/cabecalho';
import Contatos from '../components/contatos';

import {useNavigation} from '@react-navigation/native';

const Agendamento = () => {

  const navigation = useNavigation();

  return ( 
    <>
     <Cabecalho 
    title = {'Contatos para Agendamento'}
    goBack= {() => navigation.goBack()}
    />
     <Contatos
     titulo = {'xx xxxx-xxxx'}
     subtitulo = {'Telefone'}
     icone = {'phone-classic'}
     />
     <Contatos
     titulo = {'(XX) 00000-0000'}
     subtitulo = {'WhatsApp'} 
     icone = {'whatsapp'}
     />
     <Contatos 
     titulo = {'@ PerfilEstabelecimento'}
     subtitulo = {'Facebook'}
     icone = {'facebook'}
     />
     <Contatos 
     titulo = {'@ PerfilEstabelecimento'}
     subtitulo = {'Twitter'}
     icone = {'twitter'}
     />
     <Contatos 
     titulo = {'@ PerfilEstabelecimento'}
     subtitulo = {'Instagram'}
     icone = {'instagram'}
     />
    </>
  );
};

export default Agendamento;

