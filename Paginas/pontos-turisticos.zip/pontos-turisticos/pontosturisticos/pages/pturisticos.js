import * as React from 'react';
import {ScrollView } from 'react-native';


import Cabecalho from '../components/cabecalho';
import Bodypturisticos from '../components/bodypturisticos';

import {useNavigation} from '@react-navigation/native';

const Pontosturisticos = () => {

const navigation = useNavigation(); 

  return (
    <>
    <Cabecalho 
    title = {'Pontos Turísticos'}
    goBack= {() => navigation.goBack()}
    />

    <ScrollView>
    <Bodypturisticos 
    foto = {{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/74f855fb5b2331175642d1a9b649106d', }}
    titulo = {'Teatro Amazonas'} 
    texto = {'O Teatro Amazonas é um dos mais importantes teatros do Brasil e o principal cartão-postal da cidade de Manaus.'}
    clicou = {() => navigation.navigate ('Anna')} 
    textodobotao = {'Saiba mais'}  
    />
    
    <Bodypturisticos
      foto = {{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/b02ffc24d2c210efd43437e230fa6247',}}
      titulo = {'Pedra Rochosa - Jericoacoara'} 
      texto = {'A Pedra Furada é o grande símbolo de Jericoacoara.'}
      clicou = {() => navigation.navigate ('Pedra Rochosa')} 
      textodobotao = {'Saiba mais'}
    />

    <Bodypturisticos 
    foto = {{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/bacc79a26e1865cf14e87011e0c9f625', }}
    titulo = {'Teatro Municipal de São Paulo'} 
    texto = {'O Teatro Municipal de São Paulo é um teatro brasileiro localizado na cidade paulista de São Paulo.'}
    clicou = {() => navigation.navigate ('Teatro Municipal de São Paulo')}
    textodobotao = {'Saiba mais'} 
    />   

    <Bodypturisticos  
    foto = {{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/13a847dddf5314aa0881a8e945ae0ec1', }}
    titulo = {'Igreja de São Francisco de Assis - Ouro Preto'} 
    texto = {'É considerada uma das mais importantes igrejas coloniais do país, pois reúne Aleijadinho, que fez o projeto, com mestre Ataíde, principal nome da pintura na época.'}
    clicou = {() => navigation.navigate ('Igreja São Fransciso - Ouro Preto')}
    textodobotao = {'Saiba mais'}
    />

    </ScrollView>

    </>
);

};

export default Pontosturisticos;