import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();

import Pontosturisticos from '../pages/pturisticos';
import Teatroamazonas from '../pages/Teatroamazonas';
import Pedrarochosa from '../pages/pedrarochosa';
import Teatromunicipaldesp from '../pages/Teatromunicipaldesp';
import Igrejasaofrancisco from '../pages/Igrejasaofrancisco';
import Agendamento from '../pages/Agendamento';

const Main = () => {
  


 return (
  <Stack.Navigator initialRouteName="Pontos Turisticos">
    <Stack.Screen 
      name="Pontos Turisticos" 
      component={Pontosturisticos} 
      options={{
      header:() => null,
      }}
      />
    <Stack.Screen 
      name="Anna" 
      component={Teatroamazonas} 
      options={{
      header:() => null,
      }}
      />
    <Stack.Screen 
      name="Pedra Rochosa" 
      component={Pedrarochosa} 
      options={{
      header:() => null,
      }}
      />
    <Stack.Screen 
      name="Teatro Municipal de São Paulo" 
      component={Teatromunicipaldesp} 
      options={{
      header:() => null,
      }}
      />
    <Stack.Screen 
      name="Igreja São Fransciso - Ouro Preto" 
      component={Igrejasaofrancisco} 
      options={{
      header:() => null,
      }}
      />
    <Stack.Screen 
      name="Agendamento" 
      component={Agendamento} 
      options={{
      header:() => null,
      }}
      />
  </Stack.Navigator>

 );
};

export default Main;


