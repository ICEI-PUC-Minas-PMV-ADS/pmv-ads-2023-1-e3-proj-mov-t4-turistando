import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();

import OndeComer from '../pages/OndeComer';
import Cafeteria from '../pages/CafeteriaMustafa';
import Padaria from '../pages/PadariaYollanda';
import Quiosque from '../pages/QuiosqueMarina';
import Restaurante from '../pages/RestauranteVaranda';
import Agendamento from '../pages/Agendamento';

const Main = () => {

  return (

    <Stack.Navigator initialRouteName="Onde Comer">
        <Stack.Screen 
        name="Onde Comer" 
        component={OndeComer} 
        options={{
          header:() => null,
        }}
        />
        <Stack.Screen 
        name="Cafeteria" 
        component={Cafeteria} 
        options={{
          header:() => null,
        }}
        />
        <Stack.Screen 
        name="Padaria" 
        component={Padaria} 
        options={{
          header:() => null,
        }}
        />
        <Stack.Screen 
        name="Quiosque" 
        component={Quiosque} 
        options={{
          header:() => null,
        }}
        />
        <Stack.Screen 
        name="Restaurante" 
        component={Restaurante} 
        options={{
          header:() => null,
        }}
        />
        <Stack.Screen 
        name="Agendamento" 
        component={Agendamento} 
        options={{
          header:() => null,
        }}
        />
      </Stack.Navigator>

  );

};

export default Main;